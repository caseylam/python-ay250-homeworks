Casey Lam (casey_lam@berkeley.edu)

Homework 3 for Ay250, Spring 2022.

Submission: Tuesday Feb 15, 2022.